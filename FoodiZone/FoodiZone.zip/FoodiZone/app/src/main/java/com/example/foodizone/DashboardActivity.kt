package com.example.foodizone

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class DashboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        //get data from intent
        val intent = intent
        val phone = intent.getStringExtra("Phone")
        val pswrd = intent.getStringExtra("Password")

        //textview
        val resultTv = findViewById<TextView>(R.id.tv_dashboard)
        //setText
        resultTv.text = "Phone: "+phone+"\nPassword: "+pswrd
    }
}
